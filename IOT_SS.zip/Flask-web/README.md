Di chuyển vào thư mục pi/main

Bật môi trường ảo, để có thể cài các thư viện (vì pi cấm)
    source myvenv/bin/activate

Cài đặt toàn bộ thư viện:
    pip install -r requirements.txt

# thoát môi trường ảo bằng lệnh diactivate